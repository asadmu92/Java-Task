
package bscs;
import java.util.Scanner;
public class testExample {
    public static void main(String[] args) {
        
        Scanner obj =new Scanner(System.in);
        
        
        
        System.out.println("Enter a Number1:");
        int n1 = obj.nextInt();
        
        System.out.println("Enter a Number2:");
        int n2 = obj.nextInt();
        
        System.out.println("Result:"+ (n1+n2));
    }
}
