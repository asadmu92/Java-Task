
package bscs;

public class Cat extends Animal{

   
    public void climb()
    {
        System.out.println("Cat can climb");
    }
}
