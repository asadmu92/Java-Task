
package bscs;

public class Student {
    
    // properties
    public int id;
    public String Name;
    public String Lname;
    
    //method
    public void Details()
    {
        System.out.println("Id:"+id);
        System.out.println("Name:"+Name);
        System.out.println("Last Name:"+Lname);
    }
}
