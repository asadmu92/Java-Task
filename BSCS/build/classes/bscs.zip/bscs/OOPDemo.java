/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bscs;

import java.util.Date;


class cat{
    
    // properties
    public String name;
    public String color;
    public Date dob; 
    
    //action
    public void sound()
    {
        System.out.println("Meow Meow");
    }
    
}
public class OOPDemo {
    public static void main(String[] args) {
        
        // creating object
        cat c1= new cat();
        cat c2= new cat();
        
        
        
        
    }
}
