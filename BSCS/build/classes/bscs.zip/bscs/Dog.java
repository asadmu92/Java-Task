
package bscs;

public class Dog extends Animal {
    
    
    
}
