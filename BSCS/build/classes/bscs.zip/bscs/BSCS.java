
package bscs;


public class BSCS {

 
    public static void main(String[] args) {
        float saalary = 25000.00f;
        float percentage =(20.0f/100.0f); // 0.10
        float increment = saalary * percentage;
        System.out.println("Salary:" + saalary);
        System.out.println("Increment:" + increment);
        System.out.println("Icremented Salary:" + (saalary+increment));
        
       
    }
    
}
